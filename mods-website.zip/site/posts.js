/* ============================================================
   هنا تضيف منشوراتك. كل منشور = كتلة واحدة بين { }
   لإضافة منشور جديد: انسخ أي كتلة والصقها فوق الأولى وعدّل البيانات.

   game     : gta5  |  beamng  |  ac
   category : graphics (رسوميات) | cars (سيارات) | maps (خرائط) | mods (مودات)
   image    : رابط صورة أو مسار مثل "images/car1.jpg" (اتركه "" إن لم تكن هناك صورة)
   download : رابط التحميل. إما ملف داخل الموقع مثل "files/mod.zip"
              أو رابط خارجي (Mediafire, Mega, Google Drive, GitHub Releases...)
   ============================================================ */

const SITE = {
  name: "مستودع المودات",
  tagline: "سيارات، خرائط، رسوميات ومودات لـ GTA V / FiveM وBeamNG وAssetto Corsa. تحميل مباشر.",
  contact: "https://discord.gg/xxxx"   // غيّره أو اتركه "" لإخفاء الزر
};

const GAMES = {
  gta5:   { name: "GTA V / FiveM",  short: "GTA V" },
  beamng: { name: "BeamNG",         short: "BeamNG" },
  ac:     { name: "Assetto Corsa",  short: "AC" }
};

const CATEGORIES = {
  graphics: "رسوميات",
  cars:     "سيارات",
  maps:     "خرائط",
  mods:     "مودات"
};

const POSTS = [
  {
    game: "gta5", category: "cars",
    title: "مثال: سيارة سباق للـ FiveM",
    description: "هذا منشور تجريبي. احذفه أو عدّله ثم أضف منشوراتك الحقيقية.",
    image: "", download: "files/example.zip",
    size: "45 MB", version: "1.0", date: "2026-10-15"
  },
  {
    game: "gta5", category: "graphics",
    title: "مثال: حزمة رسوميات واقعية",
    description: "تحسين الإضاءة والطقس والأشجار.",
    image: "", download: "#",
    size: "120 MB", version: "2.1", date: "2026-10-14"
  },
  {
    game: "beamng", category: "maps",
    title: "مثال: خريطة جبلية",
    description: "طريق جبلي طويل مناسب للدرفت والسباقات.",
    image: "", download: "#",
    size: "300 MB", version: "1.3", date: "2026-10-13"
  },
  {
    game: "beamng", category: "mods",
    title: "مثال: مود محرك مطوّر",
    description: "يضيف خيارات محركات جديدة لعدة سيارات.",
    image: "", download: "#",
    size: "8 MB", version: "1.0", date: "2026-10-12"
  },
  {
    game: "ac", category: "cars",
    title: "مثال: سيارة GT",
    description: "موديل عالي الجودة مع صوت محرك مخصص.",
    image: "", download: "#",
    size: "80 MB", version: "1.2", date: "2026-10-11"
  },
  {
    game: "ac", category: "maps",
    title: "مثال: حلبة جديدة",
    description: "حلبة كاملة مع نقاط انطلاق متعددة.",
    image: "", download: "#",
    size: "210 MB", version: "1.0", date: "2026-10-10"
  }
];
