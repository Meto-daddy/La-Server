# مستودع المودات

موقع ثابت (بدون سيرفر) يعمل على GitHub Pages.

## النشر على GitHub (مرة واحدة)
1. أنشئ مستودعًا جديدًا على github.com (مثلًا باسم `mods`).
2. اضغط **Add file → Upload files** وارفع كل محتويات هذا المجلد، ثم **Commit changes**.
3. من **Settings → Pages**: اختر Source = `Deploy from a branch`، والفرع `main`، والمجلد `/ (root)`، ثم Save.
4. بعد دقيقة يظهر الرابط: `https://اسم-حسابك.github.io/mods/`

## إضافة منشور جديد (كل مرة)
1. ارفع ملف المود إلى مجلد `files/` (أو استخدم رابط خارجي).
2. ارفع الصورة إلى مجلد `images/` (اختياري).
3. افتح `posts.js` واضغط ✏️ للتعديل، وانسخ كتلة منشور وعدّلها:
   ```js
   {
     game: "gta5", category: "cars",
     title: "اسم السيارة",
     description: "وصف قصير",
     image: "images/car1.jpg",
     download: "files/car1.zip",
     size: "50 MB", version: "1.0", date: "2026-10-20"
   },
   ```
4. Commit، وبعد دقيقة يظهر المنشور في الموقع.

## ملاحظات مهمة
- حد GitHub للملف الواحد عند الرفع من المتصفح 25MB، ومن git 100MB.
- للملفات الكبيرة (حتى 2GB): أنشئ **Release** في المستودع وارفع الملف هناك، ثم ضع رابط التحميل في `download`.
- أو استخدم Mediafire / Mega / Google Drive وضع الرابط في `download`.
