(function(){
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? "").replace(/[&<>"']/g,
    c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const safeUrl = u => /^(https?:|files\/|images\/|\.\/|#)/i.test(u||"") ? u : "#";

  const state = { game: "all", cat: "all", q: "" };

  // الثيم (أسود / أبيض)
  const root = document.documentElement;
  try { root.dataset.theme = localStorage.getItem("theme") || "dark"; } catch(e){ root.dataset.theme="dark"; }
  $("theme").onclick = () => {
    root.dataset.theme = root.dataset.theme === "dark" ? "light" : "dark";
    try { localStorage.setItem("theme", root.dataset.theme); } catch(e){}
  };

  document.title = SITE.name;
  $("siteName").textContent = SITE.name;
  $("brand").textContent = SITE.name;
  $("tagline").textContent = SITE.tagline;
  if (SITE.contact) $("contact").href = SITE.contact; else $("contact").style.display = "none";

  // الرابط: #gta5/cars
  function readHash(){
    const [g, c] = location.hash.replace("#","").split("/");
    state.game = GAMES[g] ? g : "all";
    state.cat = CATEGORIES[c] ? c : "all";
  }
  function writeHash(){
    const parts = [];
    if (state.game !== "all") { parts.push(state.game); if (state.cat !== "all") parts.push(state.cat); }
    history.replaceState(null, "", parts.length ? "#" + parts.join("/") : location.pathname);
  }

  function renderGames(){
    const total = POSTS.length;
    let html = "";
    Object.entries(GAMES).forEach(([k, g]) => {
      const n = POSTS.filter(p => p.game === k).length;
      html += `<button class="game ${state.game===k?"active":""}" data-g="${k}"><b>${esc(g.name)}</b><span>${n} منشور</span></button>`;
    });
    $("games").innerHTML = html;
    $("games").querySelectorAll(".game").forEach(b => b.onclick = () => {
      state.game = state.game === b.dataset.g ? "all" : b.dataset.g;
      state.cat = "all"; update();
    });
  }

  function renderCats(){
    const base = POSTS.filter(p => state.game === "all" || p.game === state.game);
    let html = `<button class="cat ${state.cat==="all"?"active":""}" data-c="all">الكل (${base.length})</button>`;
    Object.entries(CATEGORIES).forEach(([k, name]) => {
      const n = base.filter(p => p.category === k).length;
      html += `<button class="cat ${state.cat===k?"active":""}" data-c="${k}">${esc(name)} (${n})</button>`;
    });
    $("cats").innerHTML = html;
    $("cats").querySelectorAll(".cat").forEach(b => b.onclick = () => { state.cat = b.dataset.c; update(); });
  }

  function renderGrid(){
    const q = state.q.trim().toLowerCase();
    const list = POSTS
      .filter(p => state.game === "all" || p.game === state.game)
      .filter(p => state.cat === "all" || p.category === state.cat)
      .filter(p => !q || (p.title + " " + p.description).toLowerCase().includes(q))
      .sort((a, b) => String(b.date).localeCompare(String(a.date)));

    $("count").textContent = list.length ? `${list.length} نتيجة` : "";
    if (!list.length){
      $("grid").innerHTML = `<div class="empty">لا توجد منشورات هنا بعد. جرّب قسمًا آخر أو أضف منشورًا جديدًا.</div>`;
      return;
    }
    $("grid").innerHTML = list.map(p => {
      const g = GAMES[p.game] || {short:"", name:""};
      const img = p.image
        ? `<img src="${esc(safeUrl(p.image))}" alt="${esc(p.title)}" loading="lazy">`
        : `<span class="ph">${esc(g.short)}</span>`;
      const date = p.date ? new Date(p.date).toLocaleDateString("ar", {year:"numeric",month:"long",day:"numeric"}) : "";
      return `<article class="card">
        <div class="thumb">${img}</div>
        <div class="body">
          <div class="tags"><span class="tag inv">${esc(g.name)}</span><span class="tag">${esc(CATEGORIES[p.category]||"")}</span></div>
          <h3>${esc(p.title)}</h3>
          <p>${esc(p.description)}</p>
          <div class="meta">
            ${p.size?`<span>الحجم: ${esc(p.size)}</span>`:""}
            ${p.version?`<span>الإصدار: ${esc(p.version)}</span>`:""}
            ${date?`<span>${esc(date)}</span>`:""}
          </div>
          <a class="btn solid" href="${esc(safeUrl(p.download))}" target="_blank" rel="noopener" download>تحميل</a>
        </div>
      </article>`;
    }).join("");
  }

  function update(){ writeHash(); renderGames(); renderCats(); renderGrid(); }

  $("search").oninput = e => { state.q = e.target.value; renderGrid(); };
  $("brand").onclick = e => { e.preventDefault(); state.game="all"; state.cat="all"; state.q=""; $("search").value=""; update(); window.scrollTo(0,0); };
  window.addEventListener("hashchange", () => { readHash(); renderGames(); renderCats(); renderGrid(); });

  readHash(); update();
})();
